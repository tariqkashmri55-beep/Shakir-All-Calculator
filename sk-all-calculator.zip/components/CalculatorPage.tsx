
import React from 'react';
import { BackArrowIcon } from './icons';

interface CalculatorPageProps {
    title: string;
    onBack: () => void;
    children: React.ReactNode;
}

const CalculatorPage: React.FC<CalculatorPageProps> = ({ title, onBack, children }) => {
    return (
        <div>
            <header className="bg-gradient-to-r from-sky-500 to-indigo-600 p-4 flex items-center shadow-lg relative">
                <button 
                    onClick={onBack} 
                    className="absolute left-4 p-2 rounded-full text-white hover:bg-white/20 transition"
                >
                    <BackArrowIcon className="w-6 h-6" />
                </button>
                <h1 className="text-xl font-bold text-white text-center w-full">{title}</h1>
            </header>
            <div className="p-4 md:p-6">
                {children}
            </div>
        </div>
    );
};

export default CalculatorPage;
