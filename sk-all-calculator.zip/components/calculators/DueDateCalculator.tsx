
import React, { useState } from 'react';

const DueDateCalculator: React.FC = () => {
    const [lastPeriodDate, setLastPeriodDate] = useState('');
    const [dueDate, setDueDate] = useState<string | null>(null);

    const calculateDueDate = () => {
        if (lastPeriodDate) {
            const date = new Date(lastPeriodDate);
            date.setDate(date.getDate() + 280); // Add 280 days (40 weeks)
            setDueDate(date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }));
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label htmlFor="lastPeriod" className="block text-sm font-medium text-slate-600 dark:text-slate-400">First day of your last menstrual period</label>
                <input 
                    type="date" 
                    id="lastPeriod" 
                    value={lastPeriodDate} 
                    onChange={e => setLastPeriodDate(e.target.value)} 
                    className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
            </div>
            <button onClick={calculateDueDate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {dueDate && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Estimated Due Date</p>
                    <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{dueDate}</p>
                </div>
            )}
        </div>
    );
};

export default DueDateCalculator;
