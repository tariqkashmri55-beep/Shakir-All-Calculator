
import React from 'react';
import { ClockIcon } from '../icons';

const ComingSoon: React.FC = () => {
    return (
        <div className="flex flex-col items-center justify-center text-center p-8 h-64 bg-slate-100 dark:bg-slate-800 rounded-lg">
            <ClockIcon className="w-16 h-16 text-indigo-400 mb-4" />
            <h2 className="text-2xl font-bold text-slate-700 dark:text-slate-300">Coming Soon!</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-2">This calculator is under construction. Please check back later.</p>
        </div>
    );
};

export default ComingSoon;
