
import React, { useState } from 'react';

const DateCalculator: React.FC = () => {
    const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
    const [operation, setOperation] = useState<'add' | 'subtract'>('add');
    const [years, setYears] = useState('');
    const [months, setMonths] = useState('');
    const [weeks, setWeeks] = useState('');
    const [days, setDays] = useState('');
    const [resultDate, setResultDate] = useState<string | null>(null);

    const calculateDate = () => {
        const date = new Date(startDate);
        const y = parseInt(years) || 0;
        const m = parseInt(months) || 0;
        const w = parseInt(weeks) || 0;
        const d = parseInt(days) || 0;

        if (operation === 'add') {
            date.setFullYear(date.getFullYear() + y);
            date.setMonth(date.getMonth() + m);
            date.setDate(date.getDate() + (w * 7) + d);
        } else {
            date.setFullYear(date.getFullYear() - y);
            date.setMonth(date.getMonth() - m);
            date.setDate(date.getDate() - (w * 7) - d);
        }

        setResultDate(date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }));
    };
    
    return (
        <div className="space-y-4">
             <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Start Date</label>
                <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
            </div>
             <div className="flex gap-4">
                <button onClick={() => setOperation('add')} className={`w-full p-2 rounded-lg ${operation === 'add' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Add</button>
                <button onClick={() => setOperation('subtract')} className={`w-full p-2 rounded-lg ${operation === 'subtract' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Subtract</button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                 <input type="number" value={years} onChange={e => setYears(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="Years" />
                 <input type="number" value={months} onChange={e => setMonths(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="Months" />
                 <input type="number" value={weeks} onChange={e => setWeeks(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="Weeks" />
                 <input type="number" value={days} onChange={e => setDays(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="Days" />
            </div>
            <button onClick={calculateDate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {resultDate && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Resulting Date</p>
                    <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{resultDate}</p>
                </div>
            )}
        </div>
    );
};

export default DateCalculator;
