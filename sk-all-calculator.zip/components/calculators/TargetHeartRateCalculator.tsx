
import React, { useState } from 'react';

const TargetHeartRateCalculator: React.FC = () => {
    const [age, setAge] = useState('');
    const [result, setResult] = useState<{ max: number; moderate: string; vigorous: string; } | null>(null);

    const calculateHeartRate = () => {
        const ageN = parseInt(age, 10);
        if (ageN > 0) {
            const maxHR = 220 - ageN;
            setResult({
                max: maxHR,
                moderate: `${Math.round(maxHR * 0.5)} - ${Math.round(maxHR * 0.7)} BPM`,
                vigorous: `${Math.round(maxHR * 0.7)} - ${Math.round(maxHR * 0.85)} BPM`,
            });
        } else {
            setResult(null);
        }
    };
    
    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Age</label>
                <input type="number" value={age} onChange={e => setAge(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 30" />
            </div>
            <button onClick={calculateHeartRate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center space-y-4">
                    <div>
                        <p className="text-lg text-slate-600 dark:text-slate-400">Maximum Heart Rate</p>
                        <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{result.max} BPM</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-center">
                        <div>
                           <p className="text-md text-slate-600 dark:text-slate-400">Moderate Intensity Zone</p>
                           <p className="text-xl font-bold text-green-500">{result.moderate}</p>
                           <p className="text-xs text-slate-500">(50-70% of max)</p>
                        </div>
                        <div>
                           <p className="text-md text-slate-600 dark:text-slate-400">Vigorous Intensity Zone</p>
                           <p className="text-xl font-bold text-red-500">{result.vigorous}</p>
                           <p className="text-xs text-slate-500">(70-85% of max)</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default TargetHeartRateCalculator;
