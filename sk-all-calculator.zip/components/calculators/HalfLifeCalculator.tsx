import React, { useState } from 'react';

const HalfLifeCalculator: React.FC = () => {
    const [initial, setInitial] = useState('');
    const [halfLife, setHalfLife] = useState('');
    const [time, setTime] = useState('');
    const [result, setResult] = useState<string | null>(null);

    const calculate = () => {
        const i = parseFloat(initial);
        const h = parseFloat(halfLife);
        const t = parseFloat(time);

        if (i > 0 && h > 0 && t >= 0) {
            const remaining = i * Math.pow(0.5, t / h);
            setResult(remaining.toExponential(4));
        } else {
            setResult(null);
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Initial Quantity</label>
                <input type="number" value={initial} onChange={e => setInitial(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 100" />
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Half-Life</label>
                    <input type="number" value={halfLife} onChange={e => setHalfLife(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 5730" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Time Elapsed</label>
                    <input type="number" value={time} onChange={e => setTime(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 2000" />
                </div>
            </div>
             <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Remaining Quantity</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default HalfLifeCalculator;
