import React, { useState } from 'react';

// MET values for various activities
const ACTIVITIES = [
    { name: 'Running (6 mph)', met: 9.8 },
    { name: 'Walking (3.5 mph)', met: 3.8 },
    { name: 'Cycling (moderate)', met: 7.5 },
    { name: 'Swimming (freestyle)', met: 9.8 },
    { name: 'Weightlifting (vigorous)', met: 6.0 },
    { name: 'Yoga', met: 2.5 },
    { name: 'Sleeping', met: 0.95 },
];

const CaloriesBurnedCalculator: React.FC = () => {
    const [activity, setActivity] = useState(ACTIVITIES[0].met);
    const [weight, setWeight] = useState('');
    const [duration, setDuration] = useState('');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
    const [result, setResult] = useState<number | null>(null);

    const calculate = () => {
        const w = parseFloat(weight);
        const d = parseFloat(duration);

        if (w > 0 && d > 0) {
            const weightKg = unit === 'metric' ? w : w / 2.20462;
            const calories = (activity * weightKg * 3.5) / 200 * d;
            setResult(Math.round(calories));
        } else {
            setResult(null);
        }
    };
    
    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric</button>
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial</button>
            </div>
            <div>
                <label className="block text-sm font-medium">Activity</label>
                <select value={activity} onChange={e => setActivity(parseFloat(e.target.value))} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm">
                    {ACTIVITIES.map(act => (
                        <option key={act.name} value={act.met}>{act.name}</option>
                    ))}
                </select>
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium">{`Weight (${unit === 'metric' ? 'kg' : 'lbs'})`}</label>
                    <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                <div>
                    <label className="block text-sm font-medium">Duration (minutes)</label>
                    <input type="number" value={duration} onChange={e => setDuration(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Estimated Calories Burned</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result.toLocaleString()}</p>
                </div>
            )}
        </div>
    );
};

export default CaloriesBurnedCalculator;
