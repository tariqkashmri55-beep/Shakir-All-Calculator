import React, { useState } from 'react';

const QuadraticFormulaCalculator: React.FC = () => {
    const [a, setA] = useState('');
    const [b, setB] = useState('');
    const [c, setC] = useState('');
    const [result, setResult] = useState<string | null>(null);

    const calculate = () => {
        const aN = parseFloat(a);
        const bN = parseFloat(b);
        const cN = parseFloat(c);

        if ([aN, bN, cN].some(isNaN) || aN === 0) {
            setResult(null);
            return;
        }

        const discriminant = bN * bN - 4 * aN * cN;

        if (discriminant > 0) {
            const x1 = (-bN + Math.sqrt(discriminant)) / (2 * aN);
            const x2 = (-bN - Math.sqrt(discriminant)) / (2 * aN);
            setResult(`x₁ = ${x1.toFixed(4)}, x₂ = ${x2.toFixed(4)}`);
        } else if (discriminant === 0) {
            const x = -bN / (2 * aN);
            setResult(`x = ${x.toFixed(4)}`);
        } else {
            const realPart = (-bN / (2 * aN)).toFixed(4);
            const imaginaryPart = (Math.sqrt(-discriminant) / (2 * aN)).toFixed(4);
            setResult(`x = ${realPart} ± ${imaginaryPart}i`);
        }
    };

    return (
        <div className="space-y-4">
            <p className="text-center text-2xl font-serif">ax² + bx + c = 0</p>
            <div className="grid grid-cols-3 gap-2">
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">a</label>
                    <input type="number" value={a} onChange={e => setA(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">b</label>
                    <input type="number" value={b} onChange={e => setB(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">c</label>
                    <input type="number" value={c} onChange={e => setC(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Solve for x</button>
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Result(s)</p>
                    <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default QuadraticFormulaCalculator;
