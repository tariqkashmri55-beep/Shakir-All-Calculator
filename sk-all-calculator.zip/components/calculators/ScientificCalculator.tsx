
import React, { useState } from 'react';
import { BackspaceIcon } from '../icons';

const Button: React.FC<{ onClick: () => void; className?: string; children: React.ReactNode }> = ({ onClick, className = '', children }) => (
    <button onClick={onClick} className={`flex items-center justify-center h-16 rounded-lg text-2xl transition-colors ${className}`}>
        {children}
    </button>
);

const ScientificCalculator: React.FC = () => {
    const [display, setDisplay] = useState('0');
    const [expression, setExpression] = useState('');

    const handleNumber = (num: string) => {
        if (display === '0') {
            setDisplay(num);
        } else {
            setDisplay(display + num);
        }
    };

    const handleOperator = (op: string) => {
        setExpression(expression + display + op);
        setDisplay('0');
    };
    
    const handleEquals = () => {
        try {
            const finalExpression = expression + display;
            // UNSAFE: Using eval for simplicity in this demo.
            // A production app should use a proper math expression parser.
            const result = eval(finalExpression.replace(/%/g, '/100'));
            setDisplay(String(result));
            setExpression('');
        } catch (error) {
            setDisplay('Error');
            setExpression('');
        }
    };

    const handleClear = () => {
        setDisplay('0');
        setExpression('');
    };

    const handleBackspace = () => {
        if (display.length > 1) {
            setDisplay(display.slice(0, -1));
        } else {
            setDisplay('0');
        }
    };

    const handleDecimal = () => {
        if (!display.includes('.')) {
            setDisplay(display + '.');
        }
    };

    return (
        <div className="bg-slate-200 dark:bg-slate-800 p-4 rounded-lg shadow-inner">
            <div className="bg-slate-100 dark:bg-slate-900 rounded-lg p-4 mb-4 text-right">
                <div className="text-slate-500 dark:text-slate-400 h-6 truncate">{expression}</div>
                <div className="text-5xl font-light break-all">{display}</div>
            </div>
            <div className="grid grid-cols-4 gap-2">
                <Button onClick={() => handleClear()} className="bg-red-400/80 dark:bg-red-500/80 text-white hover:bg-red-500">C</Button>
                <Button onClick={() => handleOperator('/')} className="bg-slate-300 dark:bg-slate-700 hover:bg-slate-400">÷</Button>
                <Button onClick={() => handleOperator('*')} className="bg-slate-300 dark:bg-slate-700 hover:bg-slate-400">×</Button>
                <Button onClick={handleBackspace} className="bg-slate-300 dark:bg-slate-700 hover:bg-slate-400"><BackspaceIcon className="w-8 h-8" /></Button>

                <Button onClick={() => handleNumber('7')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">7</Button>
                <Button onClick={() => handleNumber('8')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">8</Button>
                <Button onClick={() => handleNumber('9')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">9</Button>
                <Button onClick={() => handleOperator('-')} className="bg-slate-300 dark:bg-slate-700 hover:bg-slate-400">−</Button>

                <Button onClick={() => handleNumber('4')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">4</Button>
                <Button onClick={() => handleNumber('5')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">5</Button>
                <Button onClick={() => handleNumber('6')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">6</Button>
                <Button onClick={() => handleOperator('+')} className="bg-slate-300 dark:bg-slate-700 hover:bg-slate-400">+</Button>

                <Button onClick={() => handleNumber('1')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">1</Button>
                <Button onClick={() => handleNumber('2')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">2</Button>
                <Button onClick={() => handleNumber('3')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">3</Button>
                <Button onClick={handleEquals} className="row-span-2 bg-indigo-500 text-white hover:bg-indigo-600">=</Button>

                <Button onClick={() => handleOperator('%')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">%</Button>
                <Button onClick={() => handleNumber('0')} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">0</Button>
                <Button onClick={handleDecimal} className="bg-slate-100 dark:bg-slate-600 hover:bg-slate-200">.</Button>
            </div>
        </div>
    );
};

export default ScientificCalculator;
