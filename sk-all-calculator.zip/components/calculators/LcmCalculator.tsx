import React, { useState } from 'react';

const gcf = (a: number, b: number): number => {
    return b === 0 ? a : gcf(b, a % b);
};

const LcmCalculator: React.FC = () => {
    const [num1, setNum1] = useState('');
    const [num2, setNum2] = useState('');
    const [result, setResult] = useState<number | null>(null);

    const calculate = () => {
        const n1 = parseInt(num1, 10);
        const n2 = parseInt(num2, 10);
        if (!isNaN(n1) && !isNaN(n2) && n1 !== 0 && n2 !== 0) {
            const lcm = Math.abs(n1 * n2) / gcf(n1, n2);
            setResult(lcm);
        } else {
            setResult(null);
        }
    };

    return (
        <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Number 1</label>
                    <input type="number" value={num1} onChange={e => setNum1(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Number 2</label>
                    <input type="number" value={num2} onChange={e => setNum2(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate LCM</button>
            
            {result !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Least Common Multiple</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result.toLocaleString()}</p>
                </div>
            )}
        </div>
    );
};

export default LcmCalculator;
