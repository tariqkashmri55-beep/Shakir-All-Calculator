
import React, { useState } from 'react';

const TriangleCalculator: React.FC = () => {
    const [sideA, setSideA] = useState('');
    const [sideB, setSideB] = useState('');
    const [sideC, setSideC] = useState('');
    const [result, setResult] = useState<{ area: string; perimeter: string } | null>(null);
    const [error, setError] = useState('');

    const calculateTriangle = () => {
        const a = parseFloat(sideA);
        const b = parseFloat(sideB);
        const c = parseFloat(sideC);

        if (a > 0 && b > 0 && c > 0) {
            // Triangle inequality theorem
            if (a + b > c && a + c > b && b + c > a) {
                const perimeter = a + b + c;
                const s = perimeter / 2; // semi-perimeter
                // Heron's formula for area
                const area = Math.sqrt(s * (s - a) * (s - b) * (s - c));
                setResult({
                    area: area.toFixed(2),
                    perimeter: perimeter.toFixed(2),
                });
                setError('');
            } else {
                setError('These side lengths do not form a valid triangle.');
                setResult(null);
            }
        }
    };

    return (
        <div className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
                 <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Side A</label>
                    <input type="number" value={sideA} onChange={e => setSideA(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Side B</label>
                    <input type="number" value={sideB} onChange={e => setSideB(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Side C</label>
                    <input type="number" value={sideC} onChange={e => setSideC(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
            </div>
            
            <button onClick={calculateTriangle} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {error && <p className="text-red-500 text-center">{error}</p>}

            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <p className="text-lg text-slate-600 dark:text-slate-400">Area</p>
                            <p className="text-4xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result.area}</p>
                        </div>
                        <div>
                            <p className="text-lg text-slate-600 dark:text-slate-400">Perimeter</p>
                            <p className="text-4xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result.perimeter}</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default TriangleCalculator;
