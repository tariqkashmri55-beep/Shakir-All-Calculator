
import React, { useState } from 'react';

const DistanceCalculator: React.FC = () => {
    const [x1, setX1] = useState('');
    const [y1, setY1] = useState('');
    const [x2, setX2] = useState('');
    const [y2, setY2] = useState('');
    const [distance, setDistance] = useState<string | null>(null);

    const calculateDistance = () => {
        const x1n = parseFloat(x1);
        const y1n = parseFloat(y1);
        const x2n = parseFloat(x2);
        const y2n = parseFloat(y2);

        if (![x1n, y1n, x2n, y2n].some(isNaN)) {
            const dist = Math.sqrt(Math.pow(x2n - x1n, 2) + Math.pow(y2n - y1n, 2));
            setDistance(dist.toFixed(4));
        } else {
            setDistance(null);
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Point 1</label>
                <div className="grid grid-cols-2 gap-2 mt-1">
                    <input type="number" value={x1} onChange={e => setX1(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="x1" />
                    <input type="number" value={y1} onChange={e => setY1(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="y1" />
                </div>
            </div>
             <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Point 2</label>
                <div className="grid grid-cols-2 gap-2 mt-1">
                    <input type="number" value={x2} onChange={e => setX2(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="x2" />
                    <input type="number" value={y2} onChange={e => setY2(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="y2" />
                </div>
            </div>
            <button onClick={calculateDistance} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate Distance</button>
            
            {distance !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Distance</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{distance}</p>
                </div>
            )}
        </div>
    );
};

export default DistanceCalculator;
