import React, { useState } from 'react';

const ArmyBodyFatCalculator: React.FC = () => {
    const [gender, setGender] = useState<'male' | 'female'>('male');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('imperial');
    const [height, setHeight] = useState('');
    const [neck, setNeck] = useState('');
    const [waist, setWaist] = useState('');
    const [hip, setHip] = useState('');
    const [result, setResult] = useState<number | null>(null);

    const calculate = () => {
        const h = parseFloat(height);
        const n = parseFloat(neck);
        const w = parseFloat(waist);
        const p = parseFloat(hip);

        if (h > 0 && n > 0 && w > 0) {
            const hIn = unit === 'metric' ? h / 2.54 : h;
            const nIn = unit === 'metric' ? n / 2.54 : n;
            const wIn = unit === 'metric' ? w / 2.54 : w;
            const pIn = unit === 'metric' ? p / 2.54 : p;

            let bfp: number;

            if (gender === 'male') {
                if(wIn <= nIn) { setResult(null); return; }
                bfp = 86.010 * Math.log10(wIn - nIn) - 70.041 * Math.log10(hIn) + 36.76;
            } else {
                if (p <= 0) { setResult(null); return; }
                 if(wIn + pIn <= nIn) { setResult(null); return; }
                bfp = 163.205 * Math.log10(wIn + pIn - nIn) - 97.684 * Math.log10(hIn) - 78.387;
            }
            
            if (bfp > 0 && bfp < 100) {
                setResult(bfp);
            } else {
                setResult(null);
            }
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial</button>
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric</button>
            </div>
            <div>
                <label className="block text-sm font-medium">Gender</label>
                <select value={gender} onChange={e => setGender(e.target.value as any)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium">{`Height (${unit === 'imperial' ? 'in' : 'cm'})`}</label>
                    <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                 <div>
                    <label className="block text-sm font-medium">{`Neck (${unit === 'imperial' ? 'in' : 'cm'})`}</label>
                    <input type="number" value={neck} onChange={e => setNeck(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                 <div>
                    <label className="block text-sm font-medium">{`Waist (${unit === 'imperial' ? 'in' : 'cm'})`}</label>
                    <input type="number" value={waist} onChange={e => setWaist(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                {gender === 'female' && (
                     <div>
                        <label className="block text-sm font-medium">{`Hip (${unit === 'imperial' ? 'in' : 'cm'})`}</label>
                        <input type="number" value={hip} onChange={e => setHip(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                    </div>
                )}
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            {result !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Army Body Fat Percentage</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result.toFixed(1)}%</p>
                </div>
            )}
        </div>
    );
};

export default ArmyBodyFatCalculator;
