import React, { useState } from 'react';

const FactorCalculator: React.FC = () => {
    const [num, setNum] = useState('');
    const [factors, setFactors] = useState<number[]>([]);

    const calculate = () => {
        const n = parseInt(num, 10);
        if (!isNaN(n)) {
            const result: Set<number> = new Set();
            for (let i = 1; i <= Math.sqrt(n); i++) {
                if (n % i === 0) {
                    result.add(i);
                    result.add(n / i);
                }
            }
            setFactors(Array.from(result).sort((a, b) => a - b));
        } else {
            setFactors([]);
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Enter an integer</label>
                <input type="number" value={num} onChange={e => setNum(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Find Factors</button>
            
            {factors.length > 0 && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg">
                     <h3 className="text-lg font-semibold text-center mb-3">Factors of {num}</h3>
                    <p className="text-center text-indigo-600 dark:text-indigo-400 break-words">
                        {factors.join(', ')}
                    </p>
                </div>
            )}
        </div>
    );
};

export default FactorCalculator;
