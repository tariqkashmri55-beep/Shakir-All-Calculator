import React, { useState } from 'react';

const PregnancyCalculator: React.FC = () => {
    const [lastPeriodDate, setLastPeriodDate] = useState('');
    const [result, setResult] = useState<{ weeks: number; days: number; trimester: number } | null>(null);

    const calculate = () => {
        if (lastPeriodDate) {
            const today = new Date();
            const lmp = new Date(lastPeriodDate);
            
            const diffTime = Math.abs(today.getTime() - lmp.getTime());
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            
            if(diffDays >= 0) {
                const weeks = Math.floor(diffDays / 7);
                const days = diffDays % 7;
                let trimester = 1;
                if (weeks > 27) trimester = 3;
                else if (weeks > 13) trimester = 2;
                
                setResult({ weeks, days, trimester });
            } else {
                setResult(null);
            }
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">First day of your last period</label>
                <input 
                    type="date" 
                    value={lastPeriodDate} 
                    onChange={e => setLastPeriodDate(e.target.value)} 
                    className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm"
                />
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center space-y-3">
                    <p className="text-lg text-slate-600 dark:text-slate-400">You are</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-1">{result.weeks} weeks and {result.days} days pregnant</p>
                    <p className="text-xl font-semibold text-green-500">Trimester {result.trimester}</p>
                </div>
            )}
        </div>
    );
};

export default PregnancyCalculator;
