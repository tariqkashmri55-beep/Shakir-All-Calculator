import React, { useState } from 'react';

const RoundingCalculator: React.FC = () => {
    const [num, setNum] = useState('');
    const [decimals, setDecimals] = useState('0');
    const [result, setResult] = useState<string | null>(null);

    const calculate = () => {
        const n = parseFloat(num);
        const d = parseInt(decimals, 10);
        if (!isNaN(n) && !isNaN(d)) {
            const factor = Math.pow(10, d);
            const rounded = Math.round(n * factor) / factor;
            setResult(rounded.toFixed(d));
        } else {
            setResult(null);
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Number to Round</label>
                <input type="number" value={num} onChange={e => setNum(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 3.14159" />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Decimal Places</label>
                <input type="number" value={decimals} onChange={e => setDecimals(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 2" />
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Round</button>
            
            {result !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Rounded Value</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default RoundingCalculator;
