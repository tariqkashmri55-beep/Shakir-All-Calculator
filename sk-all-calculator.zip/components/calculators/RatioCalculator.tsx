import React, { useState } from 'react';

const RatioCalculator: React.FC = () => {
    const [a, setA] = useState('');
    const [b, setB] = useState('');
    const [c, setC] = useState('');
    const [d, setD] = useState('');
    const [result, setResult] = useState<string | null>(null);

    const calculate = () => {
        const aN = a !== '' ? parseFloat(a) : NaN;
        const bN = b !== '' ? parseFloat(b) : NaN;
        const cN = c !== '' ? parseFloat(c) : NaN;
        const dN = d !== '' ? parseFloat(d) : NaN;
        
        const inputs = [aN, bN, cN, dN];
        const nanCount = inputs.filter(isNaN).length;

        if (nanCount !== 1) {
            setResult('Please leave one field blank to solve for.');
            return;
        }

        let res: number;
        if (isNaN(dN)) res = (bN * cN) / aN;
        else if (isNaN(cN)) res = (aN * dN) / bN;
        else if (isNaN(bN)) res = (aN * dN) / cN;
        else res = (bN * cN) / dN;

        if (isNaN(res) || !isFinite(res)) {
            setResult('Invalid calculation');
        } else {
            setResult(`The missing value is ${res.toLocaleString()}`);
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-center gap-2">
                <input type="number" value={a} onChange={e => setA(e.target.value)} className="w-full text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="A" />
                <span className="text-xl">:</span>
                <input type="number" value={b} onChange={e => setB(e.target.value)} className="w-full text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="B" />
                <span className="text-xl">=</span>
                <input type="number" value={c} onChange={e => setC(e.target.value)} className="w-full text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="C" />
                 <span className="text-xl">:</span>
                <input type="number" value={d} onChange={e => setD(e.target.value)} className="w-full text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="D" />
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
             {result !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg font-semibold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default RatioCalculator;
