import React, { useState, useEffect } from 'react';

const BinaryCalculator: React.FC = () => {
    const [input, setInput] = useState('');
    const [inputType, setInputType] = useState<2 | 8 | 10 | 16>(10);
    const [results, setResults] = useState({ dec: '', bin: '', hex: '', oct: '' });
    const [error, setError] = useState('');

    const converters: { [key in typeof inputType]: RegExp } = {
        2: /^[01]*$/,
        8: /^[0-7]*$/,
        10: /^[0-9]*$/,
        16: /^[0-9a-fA-F]*$/,
    };

    useEffect(() => {
        if (input === '') {
            setResults({ dec: '', bin: '', hex: '', oct: '' });
            setError('');
            return;
        }

        if (!converters[inputType].test(input)) {
            setError(`Invalid ${inputType}-base number`);
            return;
        }
        
        setError('');
        const decValue = parseInt(input, inputType);
        
        if (isNaN(decValue)) {
            return;
        }

        setResults({
            dec: decValue.toString(10),
            bin: decValue.toString(2),
            hex: decValue.toString(16).toUpperCase(),
            oct: decValue.toString(8),
        });
        
    }, [input, inputType]);
    
    const handleTypeChange = (type: typeof inputType) => {
        setInputType(type);
        setInput('');
    }

    const ResultRow: React.FC<{label: string, value: string}> = ({label, value}) => (
        <div className="p-3 bg-slate-200 dark:bg-slate-700 rounded-lg flex items-center">
            <span className="font-semibold w-24 text-slate-600 dark:text-slate-400">{label}</span>
            <p className="font-mono text-indigo-600 dark:text-indigo-400 break-all">{value}</p>
        </div>
    );

    return (
        <div className="space-y-4">
            <div className="grid grid-cols-4 gap-2">
                <button onClick={() => handleTypeChange(10)} className={`p-2 rounded-lg ${inputType === 10 ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Dec</button>
                <button onClick={() => handleTypeChange(2)} className={`p-2 rounded-lg ${inputType === 2 ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Bin</button>
                <button onClick={() => handleTypeChange(16)} className={`p-2 rounded-lg ${inputType === 16 ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Hex</button>
                <button onClick={() => handleTypeChange(8)} className={`p-2 rounded-lg ${inputType === 8 ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Oct</button>
            </div>
            <div>
                 <label className="block text-sm font-medium text-slate-600 dark:text-slate-400 mb-1">Input Value</label>
                <input 
                    type="text" 
                    value={input} 
                    onChange={e => setInput(e.target.value)} 
                    className="font-mono mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
                 {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
            </div>
            
            <div className="space-y-2 pt-4">
                <ResultRow label="Decimal" value={results.dec} />
                <ResultRow label="Binary" value={results.bin} />
                <ResultRow label="Hexadecimal" value={results.hex} />
                <ResultRow label="Octal" value={results.oct} />
            </div>
        </div>
    );
};

export default BinaryCalculator;
