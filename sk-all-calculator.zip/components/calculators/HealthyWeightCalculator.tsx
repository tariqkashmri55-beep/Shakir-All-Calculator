import React, { useState } from 'react';

const HealthyWeightCalculator: React.FC = () => {
    const [height, setHeight] = useState('');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
    const [result, setResult] = useState<string | null>(null);

    const calculate = () => {
        const h = parseFloat(height);
        if (h > 0) {
            let lowerWeight: number, upperWeight: number;
            if (unit === 'metric') {
                const hMeters = h / 100;
                lowerWeight = 18.5 * hMeters * hMeters; // kg
                upperWeight = 24.9 * hMeters * hMeters; // kg
                setResult(`${lowerWeight.toFixed(1)} kg - ${upperWeight.toFixed(1)} kg`);
            } else {
                lowerWeight = (18.5 / 703) * h * h; // lbs
                upperWeight = (24.9 / 703) * h * h; // lbs
                setResult(`${lowerWeight.toFixed(1)} lbs - ${upperWeight.toFixed(1)} lbs`);
            }
        } else {
            setResult(null);
        }
    };
    
    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric</button>
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial</button>
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{`Height (${unit === 'metric' ? 'cm' : 'inches'})`}</label>
                <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Healthy Weight Range</p>
                    <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-500">Based on a BMI of 18.5 - 24.9.</p>
                </div>
            )}
        </div>
    );
};

export default HealthyWeightCalculator;
