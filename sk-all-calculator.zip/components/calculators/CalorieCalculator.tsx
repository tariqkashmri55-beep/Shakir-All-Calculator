
import React, { useState } from 'react';

const CalorieCalculator: React.FC = () => {
    const [age, setAge] = useState('');
    const [gender, setGender] = useState<'male' | 'female'>('male');
    const [height, setHeight] = useState('');
    const [weight, setWeight] = useState('');
    const [activity, setActivity] = useState('1.2');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
    const [result, setResult] = useState<{ maintain: number; mildLoss: number; weightLoss: number; } | null>(null);

    const calculateCalories = () => {
        const ageN = parseFloat(age);
        const heightN = parseFloat(height);
        const weightN = parseFloat(weight);

        if (ageN > 0 && heightN > 0 && weightN > 0) {
            const heightCm = unit === 'metric' ? heightN : heightN * 2.54;
            const weightKg = unit === 'metric' ? weightN : weightN / 2.20462;

            let bmr: number;
            // Mifflin-St Jeor Equation
            if (gender === 'male') {
                bmr = 10 * weightKg + 6.25 * heightCm - 5 * ageN + 5;
            } else {
                bmr = 10 * weightKg + 6.25 * heightCm - 5 * ageN - 161;
            }

            const maintenance = bmr * parseFloat(activity);
            setResult({
                maintain: Math.round(maintenance),
                mildLoss: Math.round(maintenance - 250),
                weightLoss: Math.round(maintenance - 500),
            });
        } else {
            setResult(null);
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric</button>
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial</button>
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Age</label>
                    <input type="number" value={age} onChange={e => setAge(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Gender</label>
                    <select value={gender} onChange={e => setGender(e.target.value as 'male'|'female')} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'metric' ? 'Height (cm)' : 'Height (in)'}</label>
                    <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'metric' ? 'Weight (kg)' : 'Weight (lbs)'}</label>
                    <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
            </div>
             <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Activity Level</label>
                 <select value={activity} onChange={e => setActivity(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm">
                    <option value="1.2">Sedentary (little or no exercise)</option>
                    <option value="1.375">Lightly active (light exercise/sports 1-3 days/week)</option>
                    <option value="1.55">Moderately active (moderate exercise/sports 3-5 days/week)</option>
                    <option value="1.725">Very active (hard exercise/sports 6-7 days a week)</option>
                    <option value="1.9">Extra active (very hard exercise/sports & physical job)</option>
                </select>
            </div>
            <button onClick={calculateCalories} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>

            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center space-y-4">
                    <div>
                        <p className="text-lg text-slate-600 dark:text-slate-400">Maintenance Calories</p>
                        <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{result.maintain.toLocaleString()}</p>
                        <p className="text-sm text-slate-500 dark:text-slate-500">calories/day</p>
                    </div>
                     <div className="grid grid-cols-2 gap-4 text-center">
                        <div>
                           <p className="text-md text-slate-600 dark:text-slate-400">Mild Weight Loss</p>
                           <p className="text-2xl font-bold text-green-500">{result.mildLoss.toLocaleString()}</p>
                           <p className="text-xs text-slate-500">0.5 lb/week</p>
                        </div>
                        <div>
                           <p className="text-md text-slate-600 dark:text-slate-400">Weight Loss</p>
                           <p className="text-2xl font-bold text-green-600">{result.weightLoss.toLocaleString()}</p>
                           <p className="text-xs text-slate-500">1 lb/week</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default CalorieCalculator;
