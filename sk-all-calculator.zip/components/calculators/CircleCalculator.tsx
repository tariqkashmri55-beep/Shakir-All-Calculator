
import React, { useState } from 'react';

const CircleCalculator: React.FC = () => {
    const [radius, setRadius] = useState('');
    const [result, setResult] = useState<{ area: string; circumference: string; diameter: string } | null>(null);

    const calculateCircle = () => {
        const r = parseFloat(radius);
        if (r > 0) {
            setResult({
                area: (Math.PI * r * r).toFixed(2),
                circumference: (2 * Math.PI * r).toFixed(2),
                diameter: (2 * r).toFixed(2),
            });
        } else {
            setResult(null);
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Radius</label>
                <input type="number" value={radius} onChange={e => setRadius(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
            </div>
            <button onClick={calculateCircle} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                     <div className="grid grid-cols-3 gap-2 text-center">
                        <div>
                           <p className="text-md text-slate-600 dark:text-slate-400">Area</p>
                           <p className="text-2xl font-bold text-indigo-500">{result.area}</p>
                        </div>
                         <div>
                           <p className="text-md text-slate-600 dark:text-slate-400">Circumference</p>
                           <p className="text-2xl font-bold text-indigo-500">{result.circumference}</p>
                        </div>
                        <div>
                           <p className="text-md text-slate-600 dark:text-slate-400">Diameter</p>
                           <p className="text-2xl font-bold text-indigo-500">{result.diameter}</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default CircleCalculator;
