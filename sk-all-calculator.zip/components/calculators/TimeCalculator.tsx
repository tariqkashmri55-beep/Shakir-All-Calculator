
import React, { useState } from 'react';

const TimeCalculator: React.FC = () => {
    const [h1, setH1] = useState(''); const [m1, setM1] = useState(''); const [s1, setS1] = useState('');
    const [h2, setH2] = useState(''); const [m2, setM2] = useState(''); const [s2, setS2] = useState('');
    const [operation, setOperation] = useState<'add' | 'subtract'>('add');
    const [result, setResult] = useState<string | null>(null);

    const calculateTime = () => {
        let totalSeconds1 = (parseInt(h1) || 0) * 3600 + (parseInt(m1) || 0) * 60 + (parseInt(s1) || 0);
        let totalSeconds2 = (parseInt(h2) || 0) * 3600 + (parseInt(m2) || 0) * 60 + (parseInt(s2) || 0);
        
        let resultSeconds = operation === 'add' ? totalSeconds1 + totalSeconds2 : totalSeconds1 - totalSeconds2;
        
        const sign = resultSeconds < 0 ? '-' : '';
        resultSeconds = Math.abs(resultSeconds);

        const hours = Math.floor(resultSeconds / 3600);
        resultSeconds %= 3600;
        const minutes = Math.floor(resultSeconds / 60);
        const seconds = resultSeconds % 60;
        
        setResult(`${sign}${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`);
    };
    
    return (
        <div className="space-y-4">
             <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Time 1</label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                    <input type="number" value={h1} onChange={e => setH1(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="H" />
                    <input type="number" value={m1} onChange={e => setM1(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="M" />
                    <input type="number" value={s1} onChange={e => setS1(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="S" />
                </div>
            </div>
             <div className="flex justify-center my-2">
                <button onClick={() => setOperation(op => op === 'add' ? 'subtract' : 'add')} className="p-2 rounded-full bg-slate-200 dark:bg-slate-700 text-2xl font-bold">
                    {operation === 'add' ? '+' : '-'}
                </button>
            </div>
             <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Time 2</label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                     <input type="number" value={h2} onChange={e => setH2(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="H" />
                    <input type="number" value={m2} onChange={e => setM2(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="M" />
                    <input type="number" value={s2} onChange={e => setS2(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="S" />
                </div>
            </div>
            <button onClick={calculateTime} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Result</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default TimeCalculator;
