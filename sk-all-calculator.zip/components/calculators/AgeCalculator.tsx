
import React, { useState } from 'react';

const AgeCalculator: React.FC = () => {
    const [birthDate, setBirthDate] = useState('');
    const [age, setAge] = useState<{ years: number; months: number; days: number } | null>(null);

    const calculateAge = () => {
        if (birthDate) {
            const today = new Date();
            const birth = new Date(birthDate);
            
            let years = today.getFullYear() - birth.getFullYear();
            let months = today.getMonth() - birth.getMonth();
            let days = today.getDate() - birth.getDate();

            if (days < 0) {
                months--;
                days += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
            }
            if (months < 0) {
                years--;
                months += 12;
            }
            
            setAge({ years, months, days });
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label htmlFor="birthDate" className="block text-sm font-medium text-slate-600 dark:text-slate-400">Your Date of Birth</label>
                <input 
                    type="date" 
                    id="birthDate"
                    value={birthDate} 
                    onChange={e => setBirthDate(e.target.value)}
                    className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
            </div>
            <button onClick={calculateAge} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate Age</button>
            
            {age && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">You are</p>
                    <div className="flex justify-center items-baseline space-x-2 my-2">
                        <span className="text-5xl font-bold text-indigo-600 dark:text-indigo-400">{age.years}</span>
                        <span className="text-xl text-slate-700 dark:text-slate-300">years</span>
                    </div>
                     <p className="text-lg text-slate-600 dark:text-slate-400">{age.months} months, and {age.days} days old.</p>
                </div>
            )}
        </div>
    );
};

export default AgeCalculator;
