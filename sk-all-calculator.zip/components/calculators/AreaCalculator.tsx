
import React, { useState, useMemo } from 'react';

type Shape = 'rectangle' | 'circle' | 'triangle';

const AreaCalculator: React.FC = () => {
    const [shape, setShape] = useState<Shape>('rectangle');
    const [inputs, setInputs] = useState<{ [key: string]: string }>({});
    const [result, setResult] = useState<string | null>(null);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setInputs({ ...inputs, [e.target.name]: e.target.value });
    };

    const calculateArea = () => {
        let area = 0;
        const { length, width, radius, base, height } = inputs;
        switch (shape) {
            case 'rectangle':
                if (length && width) area = parseFloat(length) * parseFloat(width);
                break;
            case 'circle':
                if (radius) area = Math.PI * (parseFloat(radius) ** 2);
                break;
            case 'triangle':
                if (base && height) area = 0.5 * parseFloat(base) * parseFloat(height);
                break;
        }
        if (area > 0) {
            setResult(area.toFixed(2));
        } else {
            setResult(null);
        }
    };

    const shapeFields = useMemo(() => {
        switch (shape) {
            case 'rectangle': return [{ name: 'length', label: 'Length' }, { name: 'width', label: 'Width' }];
            case 'circle': return [{ name: 'radius', label: 'Radius' }];
            case 'triangle': return [{ name: 'base', label: 'Base' }, { name: 'height', label: 'Height' }];
            default: return [];
        }
    }, [shape]);

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Shape</label>
                <select value={shape} onChange={e => { setShape(e.target.value as Shape); setInputs({}); setResult(null); }} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="rectangle">Rectangle</option>
                    <option value="circle">Circle</option>
                    <option value="triangle">Triangle</option>
                </select>
            </div>

            {shapeFields.map(field => (
                <div key={field.name}>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{field.label}</label>
                    <input 
                        type="number" 
                        name={field.name}
                        value={inputs[field.name] || ''} 
                        onChange={handleInputChange} 
                        className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" 
                    />
                </div>
            ))}
            
            <button onClick={calculateArea} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Area</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default AreaCalculator;
