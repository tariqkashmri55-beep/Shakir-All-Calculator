
import React, { useState, useMemo } from 'react';

type Shape = 'cube' | 'sphere' | 'cylinder' | 'cone';

const VolumeCalculator: React.FC = () => {
    const [shape, setShape] = useState<Shape>('cube');
    const [inputs, setInputs] = useState<{ [key: string]: string }>({});
    const [result, setResult] = useState<string | null>(null);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setInputs({ ...inputs, [e.target.name]: e.target.value });
    };

    const calculateVolume = () => {
        let volume = 0;
        const { side, radius, height } = inputs;
        switch (shape) {
            case 'cube':
                if (side) volume = parseFloat(side) ** 3;
                break;
            case 'sphere':
                if (radius) volume = (4/3) * Math.PI * (parseFloat(radius) ** 3);
                break;
            case 'cylinder':
                if (radius && height) volume = Math.PI * (parseFloat(radius) ** 2) * parseFloat(height);
                break;
            case 'cone':
                if (radius && height) volume = (1/3) * Math.PI * (parseFloat(radius) ** 2) * parseFloat(height);
                break;
        }
        if (volume > 0) {
            setResult(volume.toFixed(2));
        } else {
            setResult(null);
        }
    };

    const shapeFields = useMemo(() => {
        switch (shape) {
            case 'cube': return [{ name: 'side', label: 'Side Length' }];
            case 'sphere': return [{ name: 'radius', label: 'Radius' }];
            case 'cylinder': return [{ name: 'radius', label: 'Radius' }, { name: 'height', label: 'Height' }];
            case 'cone': return [{ name: 'radius', label: 'Radius' }, { name: 'height', label: 'Height' }];
            default: return [];
        }
    }, [shape]);

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Shape</label>
                <select value={shape} onChange={e => { setShape(e.target.value as Shape); setInputs({}); setResult(null); }} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm">
                    <option value="cube">Cube</option>
                    <option value="sphere">Sphere</option>
                    <option value="cylinder">Cylinder</option>
                    <option value="cone">Cone</option>
                </select>
            </div>

            {shapeFields.map(field => (
                <div key={field.name}>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{field.label}</label>
                    <input 
                        type="number" 
                        name={field.name}
                        value={inputs[field.name] || ''} 
                        onChange={handleInputChange} 
                        className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" 
                    />
                </div>
            ))}
            
            <button onClick={calculateVolume} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Volume</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default VolumeCalculator;
