
import React, { useState } from 'react';

const ExponentCalculator: React.FC = () => {
    const [base, setBase] = useState('');
    const [exponent, setExponent] = useState('');
    const [result, setResult] = useState<string | null>(null);

    const calculateExponent = () => {
        const b = parseFloat(base);
        const e = parseFloat(exponent);
        if (!isNaN(b) && !isNaN(e)) {
            const res = Math.pow(b, e);
            setResult(res.toLocaleString());
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-center gap-2">
                <input type="number" value={base} onChange={e => setBase(e.target.value)} className="block w-full text-2xl text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="Base" />
                <span className="text-lg font-medium">^</span>
                <input type="number" value={exponent} onChange={e => setExponent(e.target.value)} className="block w-full text-2xl text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="Exponent" />
            </div>
            <button onClick={calculateExponent} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Result</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default ExponentCalculator;
