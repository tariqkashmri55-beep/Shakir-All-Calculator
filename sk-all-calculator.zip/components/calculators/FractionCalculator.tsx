import React, { useState } from 'react';

const gcf = (a: number, b: number): number => {
    return b === 0 ? a : gcf(b, a % b);
};

const FractionCalculator: React.FC = () => {
    const [num1, setNum1] = useState('');
    const [den1, setDen1] = useState('');
    const [num2, setNum2] = useState('');
    const [den2, setDen2] = useState('');
    const [operator, setOperator] = useState('+');
    const [result, setResult] = useState<string | null>(null);

    const calculate = () => {
        const n1 = parseInt(num1, 10);
        const d1 = parseInt(den1, 10);
        const n2 = parseInt(num2, 10);
        const d2 = parseInt(den2, 10);

        if ([n1, d1, n2, d2].some(isNaN) || d1 === 0 || d2 === 0) {
            setResult('Invalid Input');
            return;
        }

        let resNum: number, resDen: number;

        switch (operator) {
            case '+':
                resNum = n1 * d2 + n2 * d1;
                resDen = d1 * d2;
                break;
            case '-':
                resNum = n1 * d2 - n2 * d1;
                resDen = d1 * d2;
                break;
            case '*':
                resNum = n1 * n2;
                resDen = d1 * d2;
                break;
            case '/':
                resNum = n1 * d2;
                resDen = d1 * n2;
                break;
            default: return;
        }
        
        if (resDen === 0) {
            setResult('Cannot divide by zero');
            return;
        }

        const commonDivisor = gcf(Math.abs(resNum), Math.abs(resDen));
        const simplifiedNum = resNum / commonDivisor;
        const simplifiedDen = resDen / commonDivisor;

        if (simplifiedDen === 1) {
            setResult(String(simplifiedNum));
        } else {
            setResult(`${simplifiedNum} / ${simplifiedDen}`);
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-center gap-4">
                {/* Fraction 1 */}
                <div className="flex flex-col items-center">
                    <input type="number" value={num1} onChange={e => setNum1(e.target.value)} className="w-20 text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="num" />
                    <hr className="w-20 border-t-2 border-slate-400 my-1" />
                    <input type="number" value={den1} onChange={e => setDen1(e.target.value)} className="w-20 text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="den" />
                </div>
                {/* Operator */}
                <select value={operator} onChange={e => setOperator(e.target.value)} className="text-3xl font-bold h-12 rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm">
                    <option value="+">+</option>
                    <option value="-">-</option>
                    <option value="*">*</option>
                    <option value="/">/</option>
                </select>
                {/* Fraction 2 */}
                <div className="flex flex-col items-center">
                    <input type="number" value={num2} onChange={e => setNum2(e.target.value)} className="w-20 text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="num" />
                    <hr className="w-20 border-t-2 border-slate-400 my-1" />
                    <input type="number" value={den2} onChange={e => setDen2(e.target.value)} className="w-20 text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="den" />
                </div>
            </div>
             <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            {result !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Result</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default FractionCalculator;
