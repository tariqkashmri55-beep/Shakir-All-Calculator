
import React, { useState } from 'react';

const OneRepMaxCalculator: React.FC = () => {
    const [weight, setWeight] = useState('');
    const [reps, setReps] = useState('');
    const [oneRepMax, setOneRepMax] = useState<number | null>(null);

    const calculateOneRepMax = () => {
        const w = parseFloat(weight);
        const r = parseFloat(reps);

        if (w > 0 && r > 0) {
            // Brzycki Formula
            const max = w / (1.0278 - 0.0278 * r);
            setOneRepMax(Math.round(max));
        } else {
            setOneRepMax(null);
        }
    };
    
    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Weight Lifted (kg or lbs)</label>
                <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 100" />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Repetitions</label>
                <input type="number" value={reps} onChange={e => setReps(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 5" />
            </div>
            <button onClick={calculateOneRepMax} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate 1RM</button>
            
            {oneRepMax !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Estimated One-Rep Max</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{oneRepMax.toLocaleString()}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-500">Using the Brzycki formula.</p>
                </div>
            )}
        </div>
    );
};

export default OneRepMaxCalculator;
