import React, { useState } from 'react';

const PregnancyWeightGainCalculator: React.FC = () => {
    const [height, setHeight] = useState('');
    const [weight, setWeight] = useState('');
    const [week, setWeek] = useState('');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
    const [result, setResult] = useState<{ range: string; note: string } | null>(null);

    const calculate = () => {
        const h = parseFloat(height);
        const w = parseFloat(weight);
        const currentWeek = parseInt(week, 10);

        if (h > 0 && w > 0 && currentWeek > 0 && currentWeek <= 42) {
            let bmi;
            if (unit === 'metric') {
                bmi = w / ((h / 100) ** 2);
            } else {
                bmi = 703 * w / (h ** 2);
            }
            
            let totalGainRange: string, note: string;

            if (bmi < 18.5) { // Underweight
                totalGainRange = unit === 'metric' ? '12.5 - 18 kg' : '28 - 40 lbs';
                note = 'Recommended gain is about 0.5 kg (1 lb) per week in the 2nd and 3rd trimesters.';
            } else if (bmi < 25) { // Normal weight
                totalGainRange = unit === 'metric' ? '11.5 - 16 kg' : '25 - 35 lbs';
                note = 'Recommended gain is about 0.5 kg (1 lb) per week in the 2nd and 3rd trimesters.';
            } else if (bmi < 30) { // Overweight
                totalGainRange = unit === 'metric' ? '7 - 11.5 kg' : '15 - 25 lbs';
                note = 'Recommended gain is about 0.2 kg (0.5 lb) per week in the 2nd and 3rd trimesters.';
            } else { // Obese
                totalGainRange = unit === 'metric' ? '5 - 9 kg' : '11 - 20 lbs';
                note = 'Recommended gain is about 0.2 kg (0.5 lb) per week in the 2nd and 3rd trimesters.';
            }
            
            setResult({ range: totalGainRange, note });
        } else {
            setResult(null);
        }
    };
    
    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric</button>
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial</button>
            </div>
            <p className="text-sm text-slate-500">Use your pre-pregnancy measurements.</p>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium">{`Height (${unit === 'metric' ? 'cm' : 'in'})`}</label>
                    <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                <div>
                    <label className="block text-sm font-medium">{`Weight (${unit === 'metric' ? 'kg' : 'lbs'})`}</label>
                    <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
            </div>
            <div>
                <label className="block text-sm font-medium">Current Week of Pregnancy</label>
                <input type="number" value={week} onChange={e => setWeek(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 20" />
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Recommended Total Weight Gain</p>
                    <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result.range}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">{result.note}</p>
                </div>
            )}
        </div>
    );
};

export default PregnancyWeightGainCalculator;
