
import React, { useState } from 'react';

const PaceCalculator: React.FC = () => {
    const [distance, setDistance] = useState('');
    const [hours, setHours] = useState('');
    const [minutes, setMinutes] = useState('');
    const [seconds, setSeconds] = useState('');
    const [pace, setPace] = useState<string | null>(null);

    const calculatePace = () => {
        const dist = parseFloat(distance);
        const h = parseFloat(hours) || 0;
        const m = parseFloat(minutes) || 0;
        const s = parseFloat(seconds) || 0;

        if (dist > 0 && (h > 0 || m > 0 || s > 0)) {
            const totalMinutes = h * 60 + m + s / 60;
            const paceValue = totalMinutes / dist;
            
            const paceMinutes = Math.floor(paceValue);
            const paceSeconds = Math.round((paceValue - paceMinutes) * 60);

            setPace(`${paceMinutes.toString().padStart(2, '0')}:${paceSeconds.toString().padStart(2, '0')} per mile/km`);
        } else {
            setPace(null);
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Distance (miles or km)</label>
                <input type="number" value={distance} onChange={e => setDistance(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 3.1" />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Time</label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                    <input type="number" value={hours} onChange={e => setHours(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="Hours" />
                    <input type="number" value={minutes} onChange={e => setMinutes(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="Minutes" />
                    <input type="number" value={seconds} onChange={e => setSeconds(e.target.value)} className="block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="Seconds" />
                </div>
            </div>
            <button onClick={calculatePace} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate Pace</button>
            
            {pace && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Your Pace</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{pace}</p>
                </div>
            )}
        </div>
    );
};

export default PaceCalculator;
