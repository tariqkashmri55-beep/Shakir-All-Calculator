
import React, { useState } from 'react';

const LogCalculator: React.FC = () => {
    const [base, setBase] = useState('10');
    const [value, setValue] = useState('');
    const [result, setResult] = useState<string | null>(null);

    const calculateLog = () => {
        const b = parseFloat(base);
        const v = parseFloat(value);
        if (b > 0 && b !== 1 && v > 0) {
            const res = Math.log(v) / Math.log(b);
            setResult(res.toLocaleString());
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex items-end justify-center gap-2">
                <span className="text-2xl font-medium">log</span>
                <input type="number" value={base} onChange={e => setBase(e.target.value)} className="block w-20 text-center text-sm rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="base" />
                <span className="text-2xl font-medium">(</span>
                <input type="number" value={value} onChange={e => setValue(e.target.value)} className="block w-full text-2xl text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="value" />
                <span className="text-2xl font-medium">)</span>
            </div>
            <button onClick={calculateLog} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Result</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default LogCalculator;
