import React, { useState } from 'react';

const RootCalculator: React.FC = () => {
    const [value, setValue] = useState('');
    const [root, setRoot] = useState('2');
    const [result, setResult] = useState<string | null>(null);

    const calculate = () => {
        const v = parseFloat(value);
        const r = parseFloat(root);
        if (!isNaN(v) && !isNaN(r) && r !== 0) {
            const res = Math.pow(v, 1 / r);
            setResult(res.toLocaleString());
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-center gap-2">
                 <input type="number" value={root} onChange={e => setRoot(e.target.value)} className="block w-16 text-center text-sm rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                <span className="text-2xl font-medium">√</span>
                <input type="number" value={value} onChange={e => setValue(e.target.value)} className="block w-full text-2xl text-center rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="value" />
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Result</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default RootCalculator;
