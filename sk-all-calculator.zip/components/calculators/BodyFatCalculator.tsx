
import React, { useState } from 'react';

const BodyFatCalculator: React.FC = () => {
    const [height, setHeight] = useState('');
    const [weight, setWeight] = useState('');
    const [age, setAge] = useState('');
    const [gender, setGender] = useState<'male' | 'female'>('male');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
    const [bodyFat, setBodyFat] = useState<number | null>(null);

    const calculateBodyFat = () => {
        const h = parseFloat(height);
        const w = parseFloat(weight);
        const a = parseFloat(age);

        if (h > 0 && w > 0 && a > 0) {
            let bmiValue;
            if (unit === 'metric') {
                bmiValue = w / ((h / 100) ** 2);
            } else {
                bmiValue = 703 * w / (h ** 2);
            }
            
            let bfp;
            const genderValue = gender === 'male' ? 1 : 0;
            // BMI-based Body Fat estimation
            bfp = (1.20 * bmiValue) + (0.23 * a) - (10.8 * genderValue) - 5.4;

            if (bfp > 0) {
              setBodyFat(bfp);
            } else {
              setBodyFat(null);
            }
        } else {
            setBodyFat(null);
        }
    };
    
    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric</button>
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial</button>
            </div>
            <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'metric' ? 'Height (cm)' : 'Height (in)'}</label>
                    <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'metric' ? 'Weight (kg)' : 'Weight (lbs)'}</label>
                    <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Age</label>
                    <input type="number" value={age} onChange={e => setAge(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Gender</label>
                    <select value={gender} onChange={e => setGender(e.target.value as 'male' | 'female')} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                </div>
            </div>
            <button onClick={calculateBodyFat} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {bodyFat !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Estimated Body Fat</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{bodyFat.toFixed(1)}%</p>
                    <p className="text-sm text-slate-500 dark:text-slate-500">Note: This is an estimation using the BMI method.</p>
                </div>
            )}
        </div>
    );
};

export default BodyFatCalculator;
