
import React, { useState } from 'react';

const BmiCalculator: React.FC = () => {
    const [height, setHeight] = useState('');
    const [weight, setWeight] = useState('');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
    const [bmi, setBmi] = useState<number | null>(null);
    const [category, setCategory] = useState('');

    const calculateBmi = () => {
        const h = parseFloat(height);
        const w = parseFloat(weight);
        if (h > 0 && w > 0) {
            let bmiValue;
            if (unit === 'metric') {
                // height in cm, weight in kg -> BMI = kg / (m^2)
                bmiValue = w / ((h / 100) ** 2);
            } else {
                // height in inches, weight in lbs -> BMI = 703 * lbs / (in^2)
                bmiValue = 703 * w / (h ** 2);
            }
            setBmi(bmiValue);
            setCategory(getBmiCategory(bmiValue));
        } else {
            setBmi(null);
            setCategory('');
        }
    };

    const getBmiCategory = (bmi: number) => {
        if (bmi < 18.5) return 'Underweight';
        if (bmi < 25) return 'Normal weight';
        if (bmi < 30) return 'Overweight';
        return 'Obese';
    };

    const getCategoryColor = (category: string) => {
        switch (category) {
            case 'Underweight': return 'text-blue-500';
            case 'Normal weight': return 'text-green-500';
            case 'Overweight': return 'text-yellow-500';
            case 'Obese': return 'text-red-500';
            default: return 'text-slate-800 dark:text-slate-200';
        }
    };
    
    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric</button>
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial</button>
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'metric' ? 'Height (cm)' : 'Height (inches)'}</label>
                <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'metric' ? 'Weight (kg)' : 'Weight (lbs)'}</label>
                <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
            </div>
            <button onClick={calculateBmi} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {bmi !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Your BMI</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{bmi.toFixed(1)}</p>
                    <p className={`text-xl font-semibold ${getCategoryColor(category)}`}>{category}</p>
                </div>
            )}
        </div>
    );
};

export default BmiCalculator;
