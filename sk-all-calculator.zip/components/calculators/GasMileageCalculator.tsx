
import React, { useState } from 'react';

const GasMileageCalculator: React.FC = () => {
    const [distance, setDistance] = useState('');
    const [fuel, setFuel] = useState('');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('imperial');
    const [result, setResult] = useState<string | null>(null);

    const calculateMileage = () => {
        const d = parseFloat(distance);
        const f = parseFloat(fuel);
        if (d > 0 && f > 0) {
            if (unit === 'imperial') {
                const mpg = d / f;
                setResult(`${mpg.toFixed(2)} MPG`);
            } else {
                const lp100k = (f / d) * 100;
                setResult(`${lp100k.toFixed(2)} L/100km`);
            }
        } else {
            setResult(null);
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial (MPG)</button>
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric (L/100km)</button>
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'imperial' ? 'Distance (miles)' : 'Distance (km)'}</label>
                <input type="number" value={distance} onChange={e => setDistance(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'imperial' ? 'Fuel Used (gallons)' : 'Fuel Used (liters)'}</label>
                <input type="number" value={fuel} onChange={e => setFuel(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
            </div>
            <button onClick={calculateMileage} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Fuel Efficiency</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default GasMileageCalculator;
