
import React, { useState } from 'react';

const PercentageCalculator: React.FC = () => {
    const [percentage, setPercentage] = useState('');
    const [total, setTotal] = useState('');
    const [result, setResult] = useState<string | null>(null);

    const calculatePercentage = () => {
        const p = parseFloat(percentage);
        const t = parseFloat(total);
        if (!isNaN(p) && !isNaN(t)) {
            const res = (p / 100) * t;
            setResult(res.toLocaleString());
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">What is</label>
                <div className="flex items-center gap-2">
                    <input type="number" value={percentage} onChange={e => setPercentage(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="e.g., 5" />
                    <span className="text-lg font-medium">%</span>
                </div>
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">of</label>
                <input type="number" value={total} onChange={e => setTotal(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="e.g., 200" />
            </div>
            <button onClick={calculatePercentage} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Result</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default PercentageCalculator;
