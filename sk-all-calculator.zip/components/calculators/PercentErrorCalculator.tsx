import React, { useState } from 'react';

const PercentErrorCalculator: React.FC = () => {
    const [observed, setObserved] = useState('');
    const [trueValue, setTrueValue] = useState('');
    const [result, setResult] = useState<string | null>(null);

    const calculate = () => {
        const o = parseFloat(observed);
        const t = parseFloat(trueValue);
        if (!isNaN(o) && !isNaN(t) && t !== 0) {
            const error = (Math.abs(o - t) / Math.abs(t)) * 100;
            setResult(error.toFixed(2));
        } else {
            setResult(null);
        }
    };

    return (
        <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Observed Value</label>
                    <input type="number" value={observed} onChange={e => setObserved(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 9.8" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">True Value</label>
                    <input type="number" value={trueValue} onChange={e => setTrueValue(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 10" />
                </div>
            </div>
             <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Percent Error</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}%</p>
                </div>
            )}
        </div>
    );
};

export default PercentErrorCalculator;
