
import React, { useState } from 'react';

const FuelCostCalculator: React.FC = () => {
    const [distance, setDistance] = useState('');
    const [efficiency, setEfficiency] = useState('');
    const [price, setPrice] = useState('');
    const [cost, setCost] = useState<string | null>(null);

    const calculateCost = () => {
        const d = parseFloat(distance);
        const e = parseFloat(efficiency);
        const p = parseFloat(price);
        if (d > 0 && e > 0 && p > 0) {
            const fuelNeeded = d / e;
            const totalCost = fuelNeeded * p;
            setCost(totalCost.toFixed(2));
        } else {
            setCost(null);
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Trip Distance (miles or km)</label>
                <input type="number" value={distance} onChange={e => setDistance(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Fuel Efficiency (mpg or km/L)</label>
                <input type="number" value={efficiency} onChange={e => setEfficiency(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Fuel Price (per gallon or liter)</label>
                <input type="number" value={price} onChange={e => setPrice(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
            </div>
            <button onClick={calculateCost} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {cost && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Estimated Fuel Cost</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">${cost}</p>
                </div>
            )}
        </div>
    );
};

export default FuelCostCalculator;
