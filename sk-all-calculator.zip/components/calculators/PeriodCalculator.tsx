import React, { useState } from 'react';

const PeriodCalculator: React.FC = () => {
    const [lastPeriodDate, setLastPeriodDate] = useState('');
    const [cycleLength, setCycleLength] = useState('28');
    const [nextPeriods, setNextPeriods] = useState<string[]>([]);

    const calculate = () => {
        if (lastPeriodDate) {
            const lmp = new Date(lastPeriodDate);
            const cycle = parseInt(cycleLength, 10);
            const periods: string[] = [];
            
            if (cycle > 0) {
                for (let i = 1; i <= 3; i++) {
                    const nextDate = new Date(lmp);
                    nextDate.setDate(lmp.getDate() + (cycle * i));
                    periods.push(nextDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }));
                }
                setNextPeriods(periods);
            }
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">First day of your last period</label>
                <input 
                    type="date" 
                    value={lastPeriodDate} 
                    onChange={e => setLastPeriodDate(e.target.value)} 
                    className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm"
                />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Average Cycle Length (days)</label>
                <input 
                    type="number" 
                    value={cycleLength} 
                    onChange={e => setCycleLength(e.target.value)} 
                    className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm"
                />
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Predict Next Period</button>
            
            {nextPeriods.length > 0 && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg">
                    <h3 className="text-lg font-semibold text-center mb-3">Predicted Next Periods</h3>
                    <ul className="space-y-2">
                        {nextPeriods.map((date, index) => (
                            <li key={index} className="p-2 bg-slate-200 dark:bg-slate-700 rounded-md text-center">
                                {date}
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default PeriodCalculator;
