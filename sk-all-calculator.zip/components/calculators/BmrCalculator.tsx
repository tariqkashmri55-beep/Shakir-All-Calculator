
import React, { useState } from 'react';

const BmrCalculator: React.FC = () => {
    const [age, setAge] = useState('');
    const [gender, setGender] = useState<'male' | 'female'>('male');
    const [height, setHeight] = useState('');
    const [weight, setWeight] = useState('');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
    const [bmr, setBmr] = useState<number | null>(null);

    const calculateBmr = () => {
        const ageN = parseFloat(age);
        const heightN = parseFloat(height);
        const weightN = parseFloat(weight);

        if (ageN > 0 && heightN > 0 && weightN > 0) {
            const heightCm = unit === 'metric' ? heightN : heightN * 2.54;
            const weightKg = unit === 'metric' ? weightN : weightN / 2.20462;

            let bmrValue: number;
            // Mifflin-St Jeor Equation
            if (gender === 'male') {
                bmrValue = 10 * weightKg + 6.25 * heightCm - 5 * ageN + 5;
            } else {
                bmrValue = 10 * weightKg + 6.25 * heightCm - 5 * ageN - 161;
            }
            setBmr(Math.round(bmrValue));
        } else {
            setBmr(null);
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric</button>
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial</button>
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Age</label>
                    <input type="number" value={age} onChange={e => setAge(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Gender</label>
                    <select value={gender} onChange={e => setGender(e.target.value as 'male'|'female')} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'metric' ? 'Height (cm)' : 'Height (in)'}</label>
                    <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'metric' ? 'Weight (kg)' : 'Weight (lbs)'}</label>
                    <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
            </div>
            <button onClick={calculateBmr} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate BMR</button>
            
            {bmr !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Your Basal Metabolic Rate</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{bmr.toLocaleString()}</p>
                    <p className="text-slate-500 dark:text-slate-500">calories/day</p>
                </div>
            )}
        </div>
    );
};

export default BmrCalculator;
