
import React, { useState } from 'react';

const HorsepowerCalculator: React.FC = () => {
    const [torque, setTorque] = useState('');
    const [rpm, setRpm] = useState('');
    const [horsepower, setHorsepower] = useState<string | null>(null);

    const calculateHorsepower = () => {
        const t = parseFloat(torque);
        const r = parseFloat(rpm);
        if (t > 0 && r > 0) {
            // Formula: Horsepower = (Torque × RPM) / 5252
            const hp = (t * r) / 5252;
            setHorsepower(hp.toFixed(2));
        } else {
            setHorsepower(null);
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Torque (lb-ft)</label>
                <input type="number" value={torque} onChange={e => setTorque(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 350" />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Engine Speed (RPM)</label>
                <input type="number" value={rpm} onChange={e => setRpm(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" placeholder="e.g., 4000" />
            </div>
            <button onClick={calculateHorsepower} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {horsepower && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Engine Horsepower</p>
                    <p className="text-5xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{horsepower} HP</p>
                </div>
            )}
        </div>
    );
};

export default HorsepowerCalculator;
