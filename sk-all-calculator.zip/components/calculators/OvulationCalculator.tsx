
import React, { useState } from 'react';

const OvulationCalculator: React.FC = () => {
    const [lastPeriodDate, setLastPeriodDate] = useState('');
    const [cycleLength, setCycleLength] = useState('28');
    const [result, setResult] = useState<{ ovulationDate: string; fertileWindow: string } | null>(null);

    const calculateOvulation = () => {
        if (lastPeriodDate) {
            const date = new Date(lastPeriodDate);
            const cycle = parseInt(cycleLength, 10);
            
            // Ovulation is ~14 days before next period
            const ovulationDate = new Date(date);
            ovulationDate.setDate(date.getDate() + cycle - 14);

            const fertileStart = new Date(ovulationDate);
            fertileStart.setDate(ovulationDate.getDate() - 5);
            
            const fertileEnd = new Date(ovulationDate);
            fertileEnd.setDate(ovulationDate.getDate() + 1);

            const options: Intl.DateTimeFormatOptions = { month: 'long', day: 'numeric' };

            setResult({
                ovulationDate: ovulationDate.toLocaleDateString('en-US', { ...options, year: 'numeric' }),
                fertileWindow: `${fertileStart.toLocaleDateString('en-US', options)} - ${fertileEnd.toLocaleDateString('en-US', options)}`,
            });
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">First day of your last period</label>
                <input 
                    type="date" 
                    value={lastPeriodDate} 
                    onChange={e => setLastPeriodDate(e.target.value)} 
                    className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm"
                />
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Average Cycle Length (days)</label>
                <input 
                    type="number" 
                    value={cycleLength} 
                    onChange={e => setCycleLength(e.target.value)} 
                    className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm"
                />
            </div>
            <button onClick={calculateOvulation} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {result && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center space-y-3">
                    <div>
                        <p className="text-lg text-slate-600 dark:text-slate-400">Estimated Ovulation Date</p>
                        <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 my-1">{result.ovulationDate}</p>
                    </div>
                     <div>
                        <p className="text-lg text-slate-600 dark:text-slate-400">Estimated Fertile Window</p>
                        <p className="text-2xl font-bold text-green-500 my-1">{result.fertileWindow}</p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default OvulationCalculator;
