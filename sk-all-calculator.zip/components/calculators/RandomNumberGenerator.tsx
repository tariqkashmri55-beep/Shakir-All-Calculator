import React, { useState } from 'react';

const RandomNumberGenerator: React.FC = () => {
    const [min, setMin] = useState('1');
    const [max, setMax] = useState('100');
    const [result, setResult] = useState<number | null>(null);

    const generateRandom = () => {
        const minN = parseInt(min, 10);
        const maxN = parseInt(max, 10);
        if (!isNaN(minN) && !isNaN(maxN) && minN <= maxN) {
            const rand = Math.floor(Math.random() * (maxN - minN + 1)) + minN;
            setResult(rand);
        }
    };

    return (
        <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Minimum Value</label>
                    <input type="number" value={min} onChange={e => setMin(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Maximum Value</label>
                    <input type="number" value={max} onChange={e => setMax(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
            </div>
            <button onClick={generateRandom} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Generate</button>
            
            {result !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Your Random Number</p>
                    <p className="text-7xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result}</p>
                </div>
            )}
        </div>
    );
};

export default RandomNumberGenerator;