
import React, { useState } from 'react';

const IdealWeightCalculator: React.FC = () => {
    const [height, setHeight] = useState('');
    const [gender, setGender] = useState<'male' | 'female'>('male');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
    const [idealWeight, setIdealWeight] = useState<string | null>(null);

    const calculateIdealWeight = () => {
        const h = parseFloat(height);
        if (h > 0) {
            const heightInches = unit === 'metric' ? h / 2.54 : h;
            let weightKg = 0;

            if (heightInches > 60) { // Taller than 5 feet
                if (gender === 'male') {
                    // Devine Formula for men
                    weightKg = 50 + 2.3 * (heightInches - 60);
                } else {
                    // Devine Formula for women
                    weightKg = 45.5 + 2.3 * (heightInches - 60);
                }
            }

            if (weightKg > 0) {
                const weightLbs = weightKg * 2.20462;
                setIdealWeight(`${weightKg.toFixed(1)} kg / ${weightLbs.toFixed(1)} lbs`);
            } else {
                setIdealWeight(null);
            }
        } else {
            setIdealWeight(null);
        }
    };
    
    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric</button>
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial</button>
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">Gender</label>
                <select value={gender} onChange={e => setGender(e.target.value as 'male' | 'female')} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                </select>
            </div>
            <div>
                <label className="block text-sm font-medium text-slate-600 dark:text-slate-400">{unit === 'metric' ? 'Height (cm)' : 'Height (inches)'}</label>
                <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
            </div>
            <button onClick={calculateIdealWeight} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            
            {idealWeight && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                    <p className="text-lg text-slate-600 dark:text-slate-400">Estimated Ideal Weight</p>
                    <p className="text-4xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{idealWeight}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-500">Based on the Devine formula.</p>
                </div>
            )}
        </div>
    );
};

export default IdealWeightCalculator;
