import React, { useState } from 'react';

const LeanBodyMassCalculator: React.FC = () => {
    const [gender, setGender] = useState<'male' | 'female'>('male');
    const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
    const [height, setHeight] = useState('');
    const [weight, setWeight] = useState('');
    const [result, setResult] = useState<{ lbm: number, fat: number } | null>(null);

    const calculate = () => {
        const h = parseFloat(height);
        const w = parseFloat(weight);

        if (h > 0 && w > 0) {
            const hCm = unit === 'metric' ? h : h * 2.54;
            const wKg = unit === 'metric' ? w : w / 2.20462;
            let lbm: number;

            // Boer formula
            if (gender === 'male') {
                lbm = (0.407 * wKg) + (0.267 * hCm) - 19.2;
            } else {
                lbm = (0.252 * wKg) + (0.473 * hCm) - 48.3;
            }

            if (lbm > 0) {
                const fatPercentage = ((wKg - lbm) / wKg) * 100;
                setResult({ lbm: lbm, fat: fatPercentage });
            } else {
                setResult(null);
            }
        }
    };

    const lbmInUnits = (lbmKg: number) => {
        if (unit === 'metric') return `${lbmKg.toFixed(1)} kg`;
        return `${(lbmKg * 2.20462).toFixed(1)} lbs`;
    };

    return (
        <div className="space-y-4">
            <div className="flex gap-4">
                <button onClick={() => setUnit('metric')} className={`w-full p-2 rounded-lg ${unit === 'metric' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Metric</button>
                <button onClick={() => setUnit('imperial')} className={`w-full p-2 rounded-lg ${unit === 'imperial' ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Imperial</button>
            </div>
            <div>
                <label className="block text-sm font-medium">Gender</label>
                <select value={gender} onChange={e => setGender(e.target.value as any)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium">{`Height (${unit === 'metric' ? 'cm' : 'in'})`}</label>
                    <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
                <div>
                    <label className="block text-sm font-medium">{`Weight (${unit === 'metric' ? 'kg' : 'lbs'})`}</label>
                    <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 dark:bg-slate-800 shadow-sm" />
                </div>
            </div>
            <button onClick={calculate} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition">Calculate</button>
            {result !== null && (
                <div className="mt-6 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg text-center">
                     <div className="grid grid-cols-2 gap-4">
                        <div>
                            <p className="text-lg text-slate-600 dark:text-slate-400">Lean Body Mass</p>
                            <p className="text-4xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{lbmInUnits(result.lbm)}</p>
                        </div>
                        <div>
                            <p className="text-lg text-slate-600 dark:text-slate-400">Body Fat</p>
                            <p className="text-4xl font-bold text-indigo-600 dark:text-indigo-400 my-2">{result.fat.toFixed(1)}%</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default LeanBodyMassCalculator;
