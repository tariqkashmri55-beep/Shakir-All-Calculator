
import React from 'react';

interface CardProps {
    onClick: () => void;
    children: React.ReactNode;
}

const Card: React.FC<CardProps> = ({ onClick, children }) => {
    return (
        <div 
            onClick={onClick}
            className="bg-white dark:bg-slate-800 rounded-xl shadow-md hover:shadow-lg dark:hover:shadow-indigo-500/30 p-4 flex flex-col items-center justify-center cursor-pointer transition-all duration-300 transform hover:-translate-y-1"
        >
            {children}
        </div>
    );
};

export default Card;
